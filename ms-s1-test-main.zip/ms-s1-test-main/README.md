# ms-s1-test
This is the properties file to connect config server, eureka server and main application together.
# employee-service
# leave-service
# todo-service
# attendance-service
# user-service
# salary-service
